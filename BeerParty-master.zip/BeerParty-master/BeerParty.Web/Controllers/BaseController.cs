﻿using Microsoft.AspNetCore.Mvc;

namespace BeerParty.Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public abstract class BaseController:ControllerBase
    {
        
    }
}

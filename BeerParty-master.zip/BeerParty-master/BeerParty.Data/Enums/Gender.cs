﻿using System;


namespace BeerParty.Data.Enums
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
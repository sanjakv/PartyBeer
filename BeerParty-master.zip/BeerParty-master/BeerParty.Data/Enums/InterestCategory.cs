﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeerParty.Data.Enums
{
    public enum  InterestCategory
    {
        Sports = 1,
        Music = 2,
        Movies = 3,
        Travel = 4,
        Technology = 5,
        Arts = 6,
        Food = 7,
        Books = 8,
    }
}
